QUnit.test( "strictEqual test", function( assert ) {
  assert.strictEqual( 5, testing(), "1 and 1 have the same value and type" );
   assert.strictEqual(testing(), 6 , "testing for 6" );
});
